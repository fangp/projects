

public class node {
	int freq;
	int text;
	node left;
	node right;
	node(int freq, int text){
		this.freq = freq;
		this.text = text;
		left = null;
		right = null;
	}
}
